# -*- coding: utf-8 -*-

###############################################################################
# Author: Shaun Nicholson, Esri UK, May 2015
#
# (C) Copyright ESRI (UK) Limited 2011. All rights reserved
# ESRI (UK) Ltd, Millennium House, 65 Walton Street, Aylesbury, HP21 7QG
# Tel: +44 (0) 1296 745500  Fax: +44 (0) 1296 745544
###############################################################################

import arcpy
from arcpy import env
import sys
import os
import os.path
import inspect
import time
import datetime
import logging
from datetime import datetime
import copy
import json

import esriuk.config
import esriuk.utils.common
import esriuk.airspacemanagement.parser

###########################################################################
# Top level class to read an ACO file and process the various blocks.
#
###########################################################################
class ACOReader:

    _sourceFile = None
    _targetWS   = None

    def __init__(self, sourceFile, targetWS):
        self._sourceFile    = sourceFile
        self._targetWS      = targetWS
        pass

    def execute(self):
        esriuk.utils.common.OutputMessage(logging.DEBUG, "{0} ACOReader.execute() - Start".format(time.ctime()))

        fileParser = esriuk.airspacemanagement.parser.FileParser(self._sourceFile)
        records = fileParser.execute()

        procHeader = ProcessACOHeader()
        procHeader.processBlock(records)

        procGeometry = ProcessGeometry()
        procGeometry.processBlock(records, procHeader.getYear())

        json = {}
        json.update(procHeader.getJson())
        json.update(procGeometry.getJson())
        json.update({'metadata':{'filename':self._sourceFile}})

        esriuk.utils.common.OutputMessage(logging.DEBUG, "{0} ACOReader.execute() - Finish".format(time.ctime()))

        return json

###########################################################################
# Top level class to read an ATO file and process the various blocks.
#
###########################################################################
class ATOReader:

    _sourceFile = None
    _targetWS   = None

    def __init__(self, sourceFile, targetWS):
        self._sourceFile    = sourceFile
        self._targetWS      = targetWS
        pass

    def execute(self):
        esriuk.utils.common.OutputMessage(logging.DEBUG, "{0} ATOReader.execute() - Start".format(time.ctime()))

        fileParser = esriuk.airspacemanagement.parser.FileParser(self._sourceFile)
        records = fileParser.execute()

        procHeader = ProcessATOHeader()
        procHeader.processBlock(records)

        procGeometry = ProcessATOBlocks()
        procGeometry.processBlock(records, procHeader.getYear())

        json = {}
        json.update(procHeader.getJson())
        json.update(procGeometry.getJson())
        json.update({'metadata':{'filename':self._sourceFile}})

        esriuk.utils.common.OutputMessage(logging.DEBUG, "{0} ATOReader.execute() - Finish".format(time.ctime()))

        return json

###########################################################################
# Class to process the ACO header.
# Process the block types:
#   EXER
#   MSGID
#   AMPN
#   ACOID
#   GEODATUM
#   PERIOD
###########################################################################
class ProcessACOHeader:

    _json = {}

    def __init__(self):
        self._json = {}
        pass

    def processBlock(self, records):
        esriuk.utils.common.OutputMessage(logging.DEBUG, "{0} ProcessACOHeader.processBlock() - Start".format(time.ctime()))

        for record in records:
            if record.startswith('EXER'):
                self._json['EXER'] = esriuk.airspacemanagement.parser.parseEXER(record)
            elif record.startswith('MSGID'):
                self._json['MSGID'] = esriuk.airspacemanagement.parser.parseMSGID(record)
            elif record.startswith('AMPN'):
                self._json['AMPN'] = esriuk.airspacemanagement.parser.parseAMPN(record)
            elif record.startswith('ACOID'):
                self._json['ACOID'] = esriuk.airspacemanagement.parser.parseACOID(record)
            elif record.startswith('GEODATUM'):
                self._json['GEODATUM'] = esriuk.airspacemanagement.parser.parseGEODATUM(record)
            elif record.startswith('PERIOD'):
                self._json['PERIOD'] = esriuk.airspacemanagement.parser.parsePERIOD(record)

        esriuk.utils.common.OutputMessage(logging.DEBUG, "{0} ProcessACOHeader.processBlock() - Finish".format(time.ctime()))

        pass

    def getJson(self):
        return { 'header': self._json }

    def getYear(self):
        return self._getDate(self._json['PERIOD']['period1']).year

    def _getDate(self, timeString):
        return datetime.strptime(timeString, '%d-%m-%Y %H:%M')

###########################################################################
# Class to process an ACMID block.
# Process the block types:
#   ACMID
#   POLYGON
#   CIRCLE
#   EFFLEVEL
#   APERIOD
###########################################################################
class ProcessGeometry:

    _json = []

    def __init__(self):
        pass

    def processBlock(self, records, year):
        esriuk.utils.common.OutputMessage(logging.DEBUG, "{0} ProcessGeometry.processBlock() - Start".format(time.ctime()))

        currentRecordIndex = -1
        while currentRecordIndex < len(records):
            currentRecordIndex += 1
            if currentRecordIndex >= len(records):
                break

            if records[currentRecordIndex].startswith('ACMID'):
                self._processBlock(currentRecordIndex, records, year)

        esriuk.utils.common.OutputMessage(logging.DEBUG, "{0} ProcessGeometry.processBlock() - Finish".format(time.ctime()))

        pass

    def getJson(self):
        return { 'geometry': self._json }

    def _processBlock(self, currentRecordIndex, records, year):
        esriuk.utils.common.OutputMessage(logging.DEBUG, "{0} ProcessGeometry._processBlock()".format(time.ctime()))

        json = {}

        if records[currentRecordIndex].startswith('ACMID'):
            json['ACMID'] = esriuk.airspacemanagement.parser.parseACMID(records[currentRecordIndex])
            json['ACMID']['SORTORDER'] = len(self._json) + 1
     
        processBlock = True
        while processBlock == True:
            record = records[currentRecordIndex + 1]
            if record.startswith('POLYGON'):
                json['ACMID']['geometry'] = esriuk.airspacemanagement.parser.parsePOLYGON(record)
                currentRecordIndex += 1
            elif record.startswith('CIRCLE'):
                json['ACMID']['geometry'] = esriuk.airspacemanagement.parser.parseCIRCLE(record)
                currentRecordIndex += 1
            elif record.startswith('EFFLEVEL'):
                json['ACMID']['efflevel'] = esriuk.airspacemanagement.parser.parseEFFLEVEL(record)
                currentRecordIndex += 1
            elif record.startswith('APERIOD'):
                if json['ACMID'].has_key('period') == False:
                    json['ACMID']['period'] = []
                tempJson = esriuk.airspacemanagement.parser.parseAPERIOD(record, year)
                tempJson['SORTORDER'] = len(json['ACMID']['period']) + 1
                json['ACMID']['period'].append(tempJson)
                currentRecordIndex += 1
            else:
                processBlock = False

        self._json.append(json)

        pass

###########################################################################
# Class to process the ATO header.
# Process the block types:
#   EXER
#   MSGID
#
###########################################################################
class ProcessATOHeader:

    _json = {}

    def __init__(self):
        self._json = {}
        pass

    def processBlock(self, records):
        esriuk.utils.common.OutputMessage(logging.DEBUG, "{0} ProcessATOHeader.processBlock() - Start".format(time.ctime()))

        for record in records:
            if record.startswith('EXER'):
                self._json['EXER'] = esriuk.airspacemanagement.parser.parseEXER(record)
            elif record.startswith('MSGID'):
                self._json['MSGID'] = esriuk.airspacemanagement.parser.parseMSGID(record)
            elif record.startswith('TIMEFRAM'):
                self._json['TIMEFRAM'] = esriuk.airspacemanagement.parser._parseBlockTIMEFRAM(record)
            #elif record.startswith('ACOID'):
            #    self._parseBlockACOID(record)
            #elif record.startswith('GEODATUM'):
            #    self._parseBlockGEODATUM(record)
            #elif record.startswith('PERIOD'):
            #    self._parseBlockPERIOD(record)

        esriuk.utils.common.OutputMessage(logging.DEBUG, "{0} ProcessATOHeader.processBlock() - Finish".format(time.ctime()))

        pass

    def getJson(self):
        return { 'header': self._json }

    def getYear(self):
        return self._getDate(self._json['TIMEFRAM']['start']).year

    def _getDate(self, timeString):
        return datetime.strptime(timeString, '%d-%m-%Y %H:%M')

###########################################################################
# Class to process an ATO goemetry block.
# Process the block types:
#   AMSNDAT
#
###########################################################################
class ProcessATOBlocks:

    _json = { 'taskCountries' : []}

    def __init__(self):
        pass

    def processBlock(self, records, year):
        esriuk.utils.common.OutputMessage(logging.DEBUG, "{0} ProcessATOBlocks.processBlock() - Start".format(time.ctime()))

        taskCountry  = None
        taskUnit     = None

        currentRecordIndex = -1
        while currentRecordIndex < len(records):
            currentRecordIndex += 1
            if currentRecordIndex >= len(records):
                break

            if records[currentRecordIndex].startswith('TSKCNTRY'):
                taskCountry = esriuk.airspacemanagement.parser.parseTSKCNTRY(records[currentRecordIndex])
                taskCountry['taskUnits'] = []
                self._json['taskCountries'].append(taskCountry)
            elif records[currentRecordIndex].startswith('TASKUNIT'):
                taskUnit = esriuk.airspacemanagement.parser.parseTASKUNIT(records[currentRecordIndex])
                taskUnit['tasks'] = []
                taskCountry['taskUnits'].append(taskUnit)
            elif records[currentRecordIndex].startswith('AMSNDAT'):
                taskJson = self._processBlock(currentRecordIndex, records, year)
                taskJson['SORTORDER'] = len(taskUnit['tasks']) + 1
                taskUnit['tasks'].append(taskJson)

        esriuk.utils.common.OutputMessage(logging.DEBUG, "{0} ProcessATOBlocks.processBlock() - Finish".format(time.ctime()))

        pass

    def getJson(self):
        return self._json

    def _processBlock(self, currentRecordIndex, records, year):
        esriuk.utils.common.OutputMessage(logging.DEBUG, "{0} ProcessATOBlocks._processBlock()".format(time.ctime()))

        json = {}

        if records[currentRecordIndex].startswith('AMSNDAT'):
            json['AMSNDAT'] = esriuk.airspacemanagement.parser.parseAMSNDAT(records[currentRecordIndex])
            json['AMSNDAT']['SORTORDER'] = len(self._json) + 1
            json['AMSNDAT']['location'] = []
     
        processBlock = True
        while processBlock == True:
            record = records[currentRecordIndex + 1]
            if record.startswith('AMSNLOC'):
                json['AMSNDAT']['location'] += esriuk.airspacemanagement.parser.parseAMSNLOC(record, year)
                currentRecordIndex += 1
            elif record.startswith('MSNACFT'):
                json['AMSNDAT']['aircraft'] = esriuk.airspacemanagement.parser.parseMSNACFT(record)
                currentRecordIndex += 1
                pass
            elif record.startswith('GTGTLOC'):
                tempJson = esriuk.airspacemanagement.parser.parseGTGTLOC(record)
                tempJson['SORTORDER'] = len(json['AMSNDAT']['location']) + 1
                json['AMSNDAT']['location'].append(tempJson)
                currentRecordIndex += 1
                pass
            elif record.startswith('AMPN'):
                currentRecordIndex += 1
                pass
            elif record.startswith('NARR'):
                currentRecordIndex += 1
                pass
            else:
                processBlock = False

        return json

